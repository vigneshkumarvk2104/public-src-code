import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { tap, map, finalize, catchError, } from 'rxjs/operators';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profileDetails: any;

  constructor( private apiservice : ApiService) {
    this.profileDetails = {
      "mobile_number": "9876543211",
      "email_id": "aabc@gmail.com",
      "city": "cbe",
      "educational_background": [
        {
          "educational_background_id": 1,
          "course_level": "a",
          "school_name": "bb",
          "course_completion_year": "as",
          "board": "a",
          "subjects": "a",
          "marks": "111"
        },
        {
          "course_level": "b",
          "school_name": "s",
          "course_completion_year": "a",
          "board": "i",
          "subjects": "y",
          "marks": "111"
        }
      ],
      "work_experience": [
        {
          "work_experience_id": 1,
          "experience": "2year",
          "employer_name": "Barry",
          "designation": "developer",
          "department": "cse",
          "current_job": "yes"
        },
        {
          "experience": "1year",
          "employer_name": "oliver",
          "designation": "developer",
          "department": "IT",
          "current_job": "yes"
        }
      ],
      "education_preferences": [
        {
          "education_preferences_id": 1,
          "education_stream": "cs",
          "course": "BE",
          "specialization": "eng",
          "mode_of_study": "regular"
        },
        {
          "education_stream": "cse",
          "course": "BE",
          "specialization": "engg",
          "mode_of_study": "regular"
        }
      ]
    }
  }

  ngOnInit() {
  }

  deleteObj(value,index){
    if(value == "eduBg"){
      this.profileDetails.educational_background.splice(index,1);
    }
    else if(value == "workExp"){
      this.profileDetails.work_experience.splice(index,1);
    }
    else if(value == "eduPrefer"){
      this.profileDetails.education_preferences.splice(index,1);
    }
  }
  addMore(value) {
    if (value == "eduBg") {
      const eduBgTemplate = {
        "course_level": "",
        "school_name": "",
        "course_completion_year": "",
        "board": "",
        "subjects": "",
        "marks": ""
      }
      this.profileDetails.educational_background.push(eduBgTemplate);
    }
    else if(value == "workExp"){
      const workExpTemplate = {
        "experience": "",
        "employer_name": "",
        "designation": "",
        "department": "",
        "current_job": ""
      }
      this.profileDetails.work_experience.push(workExpTemplate);
    }
    else if(value == "eduPrefer"){
      const eduPreferTemplate = {
        "education_stream": "",
        "course": "",
        "specialization": "",
        "mode_of_study": ""
      }
      this.profileDetails.education_preferences.push(eduPreferTemplate);
    }
  }

  submitProfile(){
    this.apiservice.put('/v1/auths/1', this.profileDetails).pipe(
      tap(res => {
        if(res['Msg'] == "Successfully added"){
          alert(res['Msg']);
        }
        }
      )
    ).subscribe();
  }

}
