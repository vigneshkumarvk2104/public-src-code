import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { tap } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrls: ['./course-details.component.css']
})
export class CourseDetailsComponent implements OnInit {
  courseDetails: any;
  checkLogin = sessionStorage.getItem('token');

  constructor(private apiservice: ApiService, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.onload(params.course_id);
    });
    // this.courseDetails =
    // {
    //   "id": 1,
    //   "image_upload": "uploads/filename-1579691781066.jpg",
    //   "course_name": "BE",
    //   "category": "UG",
    //   "area_of_interest": " ",
    //   "pdf_upload": "uploads/filename-1579692102689.pdf",
    //   "overview": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "skill_set": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "eligibility_criteria": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "entrance_exam": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "course_curriculum": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "specialization": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "job_profile": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "recruiters_content": "<p>asfsagsdfjhgkjhlkj;ljcgfbadafsff</p>",
    //   "created_at": "2020-01-23T07:50:30.000Z",
    //   "updated_at": "2020-01-23T07:50:30.000Z"
    // }
  }

  onload(courseID) {
    this.apiservice.get('/v1/course/get_course/'+courseID, '').pipe(
      tap(courseDetails => {
        this.courseDetails = courseDetails.result[0];
      })
    ).subscribe();
  }

  ngOnInit() {
  }

  isShown: boolean = false;
  toggleShow() {
    this.isShown = !this.isShown;
  }

  isShown1: boolean = true;
  toggleShow1() {
    this.isShown1 = !this.isShown1;
  }

  isShown2: boolean = true;
  toggleShow2() {
    this.isShown2 = !this.isShown2;
  }

  isShown3: boolean = true;
  toggleShow3() {
    this.isShown3 = !this.isShown3;
  }

  isShown4: boolean = true;
  toggleShow4() {
    this.isShown4 = !this.isShown4;
  }

  isShown5: boolean = true;
  toggleShow5() {
    this.isShown5 = !this.isShown5;
  }

}
