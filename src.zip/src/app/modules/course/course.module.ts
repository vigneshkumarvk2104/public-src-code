import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseRoutingModule } from './course-routing.module';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { LayoutModule } from 'src/app/layouts/layout.module';

@NgModule({
  declarations: [CourseDetailsComponent],
  imports: [
    CommonModule,
    CourseRoutingModule,
    LayoutModule
  ]
})
export class CourseModule { }
