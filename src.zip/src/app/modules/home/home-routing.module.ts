import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PatnerwithusComponent } from './patnerwithus/patnerwithus.component';
import { PatnerwithusCollegeComponent } from './patnerwithus-college/patnerwithus-college.component';

const route: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: '',
    children: [
      {
        path: 'partnerWithUs',
        component: PatnerwithusComponent
      },
      {
        path: 'partnerWithUsCollege',
        component: PatnerwithusCollegeComponent
      }
    ]
  }
]


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ],
  exports:[RouterModule]
})
export class HomeRoutingModule { }
