import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-patnerwithus',
  templateUrl: './patnerwithus.component.html',
  styleUrls: ['./patnerwithus.component.css']
})
export class PatnerwithusComponent implements OnInit {
  partnerDetails: any;
  currentlyWork: any[];
  haveExp: any[];
  checkLogin = sessionStorage.getItem('token');

  constructor(private apiService: ApiService) {
    this.currentlyWork = [
      { value: "Yes", id: 1 },
      { value: "No", id: 0 }
    ]
    this.haveExp = [
      { value: "Yes", id: 1 },
      { value: "No", id: 0 }
    ]
    this.partnerDetails = {
      "first_name": "",
      "last_name": "",
      "title": "",
      "business_email": "",
      "business_phone_number": "",
      "address": "",
      "currently_working": 1,
      "experience": 0,
      "company_name": "",
      "address_line": "",
      "city": "",
      "state": "",
      "zip_code": "",
      "company_website": "",
      "designation": "",
      "degree_name": "",
      "year_of_passing": "",
      "additional_info": "",
      "admin_notes": "",
      "upload": [
        {
          "aadhar_upload": "assets/images/plus.png",
          "tenth_upload": "assets/images/plus.png",
          "twelveth_upload": "assets/images/plus.png"
        }
      ]
    }
  }

  ngOnInit() {
  }

  onSelectFile(event, index, value) {
    if(event.target.files[0]){
      let file: File = event.target.files[0];
      let formData: FormData = new FormData();
      formData.append('image', file, file.name);
      this.apiService.uploadPost('/v1/fileuploads', formData).pipe(
        tap(res => {
          if (res['Msg'] == "Successfully Added") {
            if (event.target.files[0].type == 'image/jpeg' || event.target.files[0].type == 'image/png') {
              this.partnerDetails.upload[index][value] = 'http://54.152.100.56/file/' + res['result']['filename'];
            }
            else if (event.target.files[0].type == 'application/pdf') {
              this.partnerDetails.upload[index][value] = 'http://54.152.100.56/file/' + res['result']['filename'];
            }
            else {
              alert("Please upload only images or PDF")
            }
          }
          else {
            alert("Not uploaded successfully")
          }
        })
      ).subscribe();
    }
  }

  deleteObj(value, index) {
    if (value == "uploadInfo") {
      this.partnerDetails.upload.splice(index, 1);
    }
  }

  addMore(value) {
    if (value == "uploadInfo") {
      const uploadInfoTemplate = {
        "aadhar_upload": "assets/images/plus.png",
        "tenth_upload": "assets/images/plus.png",
        "twelveth_upload": "assets/images/plus.png"
      }
      this.partnerDetails.upload.push(uploadInfoTemplate);
    }
  }

  submit() {
    this.partnerDetails['partner_type'] = 'vendor';
    this.apiService.post('/v1/partners/save_partners', this.partnerDetails).pipe(
      tap(res => {
        if (res['Msg'] == "Successfully added") {
          alert(res['Msg']);
        }
      }
      )
    ).subscribe();
  }

}
