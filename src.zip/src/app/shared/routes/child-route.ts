import { Routes } from '@angular/router';

export const ChildRoute: Routes = [
  {
    path: 'profile',
    loadChildren: 'src/app/modules/profile/profile.module#ProfileModule'
  },
  {
    path: 'college',
    loadChildren: 'src/app/modules/colleges/colleges.module#CollegesModule'
  }
];
