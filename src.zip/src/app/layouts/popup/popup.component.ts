import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { tap, map, finalize, catchError, } from 'rxjs/operators';
import { of, throwError, from } from 'rxjs';
import { AuthService } from 'src/app/core/services/auth.service'

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.css']
})
export class PopupComponent implements OnInit {
  signUpForm: FormGroup;
  name: FormControl;
  mobile_number: FormControl;
  email_id: FormControl;
  password: FormControl;
  city: FormControl;
  role_id: FormControl;
  nationality: FormControl;
  nationalityOption: any;
  userID: any;
  pwd: any;
  error: any;

  constructor(private apiservice: ApiService,private route : Router, private authService: AuthService) {
    this.createFormControler();
    this.createForm();
   }

  ngOnInit() {
    this.getNationality();
  }

  getNationality(){
    this.apiservice.get('/v1/nationalities','').pipe(
      tap(nationality => {
        this.nationalityOption = nationality.result;
      })
    ).subscribe();
  }

  createFormControler() {
    this.name = new FormControl('', Validators.required);
    this.mobile_number = new FormControl('', Validators.required);
    this.email_id = new FormControl('', Validators.required);
    this.password = new FormControl('', Validators.required);
    this.city = new FormControl('',Validators.required);
    this.nationality = new FormControl('1', Validators.required);
    this.role_id = new FormControl('1', Validators.required);
  }

  createForm() {
    this.signUpForm = new FormGroup({
      name: this.name,
      mobile_number: this.mobile_number,
      email_id: this.email_id,
      password: this.password,
      city: this.city,
      nationality: this.nationality,
      role_id: this.role_id
    })
  }

  signUp(){
    const signUpDetails = this.signUpForm.value;
    this.apiservice.post('/v1/auths', signUpDetails).pipe(
      tap(res => {
        if(res['Msg'] == "Successfully Inserted"){
          alert("Successfully SignUp");
        }
        else if(res['Msg'] == "Email already exists"){
          alert("Email already exists");
        }
      }),
      catchError(error => of(
        this.errorCall(error)
      ))
    ).subscribe();
  }

  login(email,pwd){
    if(email && pwd){
      this.authService.login(email,pwd).pipe(
        map(users => {
          console.log(users)
          if(users.auth){
            //alert(users.message);
            sessionStorage.setItem('token', users.token);
            this.route.navigate(['/profile']);
          }
          else{
            alert(users.Msg)
          }
        }),
        catchError(error => of(
          this.errorCall(error)
        ))
      ).subscribe();
    }
  }

  errorCall(val){
    alert(val.Msg);
  }

}
