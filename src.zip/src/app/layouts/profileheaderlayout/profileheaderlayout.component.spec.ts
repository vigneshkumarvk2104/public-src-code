import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileheaderlayoutComponent } from './profileheaderlayout.component';

describe('ProfileheaderlayoutComponent', () => {
  let component: ProfileheaderlayoutComponent;
  let fixture: ComponentFixture<ProfileheaderlayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileheaderlayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileheaderlayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
