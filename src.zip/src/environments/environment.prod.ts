export const environment = {
  production: true,
  server_Url : "api",
  envName : 'Production',
  version : 'v0.1'
};
